﻿namespace ConsoleApp2.Classes
{
    public class Aluno
    {
        public string Ra {  get; set; }
        public string nome {  get; set; }
        public double notabin1 { get; set; }
        public double notabin2 { get; set; }
    }
}

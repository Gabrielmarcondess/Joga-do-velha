﻿using ConsoleApp2.Classes;

var aluno1 = new Aluno();
aluno1.Ra = "2025105377";
aluno1.nome = "Gabriel";
aluno1.notabin1 = 8.0;
aluno1.notabin2 = 4.0;

var alunoo = RetornaAluno();

Aluno RetornaAluno()
{
   
    aluno1.Ra ="dsasa";
    aluno1.nome = "fdgsdfsdf";
    aluno1.notabin1 = 5.0;
    aluno1.notabin2 = 8.0;
    return aluno1;
}
void mostraInfoAluno(Aluno aluno)
{
    
    Console.WriteLine(aluno.Ra);
    Console.WriteLine(aluno.nome);
    Console.WriteLine(aluno.notabin1);
    Console.WriteLine(aluno.notabin2);

}
mostraInfoAluno(aluno1);
